#!/usr/bin/env python3

"""
Functions/classes to access and/or modify the attributes of any object(s).
Greg Conan: gregmconan@gmail.com
Created: 2025-06-02
Updated: 2026-03-02
"""
# Import standard libraries
from collections.abc import Callable, Container, Generator, Iterable, Iterator
from typing import Any, ParamSpec, TypeVar

# Import local custom libraries
try:
    from gconanpy.iters.filters import Filter
    from gconanpy.iters import IterableMap
    from gconanpy.meta import DATA_ERRORS, name_of
except (ImportError, ModuleNotFoundError):  # TODO DRY?
    from ..iters.filters import Filter
    from ..iters import IterableMap
    from ..meta import DATA_ERRORS, name_of

# Type variables for functions' input argument type hints
_P = ParamSpec("_P")  # for lazyget and lazysetdefault
_T = TypeVar("_T")  # for add_to, AttrsOf.add_to, lazyget, and lazysetdefault


def add_to(an_obj: _T, **attributes: Any) -> _T:
    """
    :param an_obj: _T: Any, object to add attributes to
    :return: _T: Any, `an_obj` now with `attributes` added
    """
    for attr_name, attr_value in attributes.items():
        setattr(an_obj, attr_name, attr_value)
    return an_obj


def get_names(*objects: Any) -> set[str]:
    """
    :param objects: Any, object(s) to return the attribute names of
    :return: set[str], the name of every attribute of all of the `objects`
    """
    names = set[str]()
    for each_obj in objects:

        # Name some of its own attributes
        names.update(dir(each_obj))

        # Name the rest of its own attributes
        for meta_attr_name in ("__dict__", "__slots__"):
            meta_attr = getattr(each_obj, meta_attr_name, None)
            if meta_attr:
                names.update(meta_attr)

        # If it's a class, name the attributes of its base class(es)
        bases = getattr(each_obj, "__bases__", None)
        if bases:
            names.update(get_names(*bases))

            # Filter out absent attribute names
            to_remove = set[str]()
            for attr_name in names:
                if not hasattr(each_obj, attr_name):
                    to_remove.add(attr_name)
            names.difference_update(to_remove)

    return names


def getdefault(obj: Any, name: str, value: Any,
               exclude: Container = set()) -> Any:
    """ Return the `name` attribute of `obj` if it exists and isn't in \
        `exclude`. Otherwise, return `value`.

    :param obj: Any, object to ensure has an attribute with that `name`
    :param name: str naming the attribute to ensure that `obj` has
    :param value: Any, new value of the `name` attribute of `obj` if that \
        attribute doesn't exist or if its value is in `exclude`
    :param exclude: Container, values of `obj.<name>` to overwrite
    :return: Any, either `getattr(obj, name)` or `value`
    """
    try:  # If obj has the attribute, return it unless its value is excluded
        gotten = getattr(obj, name)
        assert gotten not in exclude

    # If obj lacks the attribute, return the default value
    except (AssertionError, AttributeError):
        gotten = value

    # `obj.<name> in exclude` raises TypeError if obj.<name> isn't Hashable.
    # In that case, obj.<name> can't be in exclude, so obj has name.
    except TypeError:
        pass

    return gotten


def has(obj: Any, name: str, exclude: Container = set()) -> bool:
    """
    :param obj: Any, object to check whether it has an attribute called `name`
    :param name: str, name of the attribute to check for
    :param exclude: Container, values to ignore or overwrite. If `obj` \
        maps `key` to one, then return True as if `key is not in obj`.
    :return: bool, True if `key` is not mapped to a value in `obj` or \
        is mapped to something in `exclude`
    """
    try:  # If an_obj has the attribute, return True unless it doesn't count
        return getattr(obj, name) not in exclude

    except AttributeError:  # If an_obj lacks the attribute, return False
        return False

    # `obj.<name> in exclude` raises TypeError if obj.<name> isn't Hashable.
    # In that case, obj.<name> can't be in exclude, so obj has name.
    except TypeError:
        return True


def is_private(name: str, *_: Any) -> bool:
    """ If an attribute/method name starts with an underscore, then \
        assume that it's private, and vice versa if it doesn't.

    This function accepts and ignores parameters other than `name` so it \
    can be used as a filter by `AttrsOf`.

    :param name: str, _description_
    :return: bool, True if `name` starts with an underscore; else False
    """
    return name.startswith("_")


def is_read_only(obj: Any, attr_name: str) -> bool:
    """ Check if an attribute of an object is read-only by trying \
        to set the attribute to its current value.

    Adapted from stackoverflow.com/a/29632719 and stackoverflow.com/a/76208998

    WARNING: If the attribute's value changes in the instant between getting \
    it and re-setting it, then it will be set to the former value, which may \
    cause issues in some cases.

    :param obj: Any
    :param attr_name: str, name of the attribute of `obj` to check.
    :raises AttributeError: if `obj` has no attribute called `attr_name`.
    :return: bool, True if the `obj` attribute with the given `attr_name` \
        is read-only and thus cannot be modified; else False
    """
    attr = getattr(obj, attr_name)  # raise uncaught AttributeError if missing
    try:
        setattr(obj, attr_name, attr)
        return False
    except DATA_ERRORS:  # (AttributeError, TypeError):
        return True


def lazyget(an_obj: Any, name: str, get_if_absent: Callable[_P, _T],
            exclude: Container = set[Any](), *args: _P.args,
            **kwargs: _P.kwargs) -> _T | Any:
    """ Return the named attribute of `an_obj` if it exists; else \
        return `get_if_absent(*args, **kwargs)`.

    :param an_obj: Any, object to try to get an attribute of.
    :param name: str naming the attribute to try to get.
    :param get_if_absent: Callable, function to get the default value.
    :param args: Iterable[Any] of `get_if_absent` arguments.
    :param kwargs: Mapping[Any] of `get_if_absent` keyword arguments.
    :param exclude: Container of values not to return and instead return \
        `get_if_absent(*args, **kwargs)`.
    :return: Any, the `name` attribute of `an_obj` if it exists and is not \
        in `exclude`; else `get_if_absent(*args, **kwargs)`
    """
    return get_if_absent(*args, **kwargs) if \
        not has(an_obj, name, exclude) else getattr(an_obj, name)


def lazysetdefault(an_obj: Any, name: str, get_if_absent: Callable[_P, _T],
                   exclude: Container = set[Any](), *args: _P.args,
                   **kwargs: _P.kwargs) -> _T | Any:
    """ Return the named attribute of `an_obj` if it exists; else set it \
        it to `get_if_absent(*args, **kwargs)` and return that.

    :param an_obj: Any, object to get (or set) an attribute of.
    :param name: str naming the attribute to get (or set).
    :param get_if_absent: Callable, function to set & return default value.
    :param args: Iterable[Any] of `get_if_absent` arguments.
    :param kwargs: Mapping[Any] of `get_if_absent` keyword arguments.
    :param exclude: Container of possible values to replace with \
        `get_if_absent(*args, **kwargs)` and return (if \
        any of them is the named `an_obj` attribute).
    :return: Any, the `name` attribute of `an_obj` if it exists and is not \
        in `exclude`; else `get_if_absent(*args, **kwargs)`
    """
    if not has(an_obj, name, exclude):
        setattr(an_obj, name, get_if_absent(*args, **kwargs))
    return getattr(an_obj, name)


def setdefault(an_obj: Any, name: str, value: Any,
               exclude: Container = set()) -> None:
    """ If `an_obj` does not have an attribute called `name`, or if it does \
        but that attribute's value is a member of `exclude`, then set that \
        `name` attribute of `an_obj` to the specified `value`.

    :param an_obj: Any, object to ensure has an attribute with that `name`
    :param name: str naming the attribute to ensure that `an_obj` has
    :param value: Any, new value of the `name` attribute of `an_obj` if that \
        attribute doesn't exist or if its value is in `exclude`
    :param exclude: Container, values of `an_obj.<name>` to overwrite
    """
    gotten = getdefault(an_obj, name, value, exclude)
    if gotten is value:
        setattr(an_obj, name, value)
    return gotten


class AttrsOf(IterableMap):
    """ Select/iterate/copy the attributes of any object. """
    _AttrPair = tuple[str, Any]  # name-value pair

    # Generator that iterates over attribute name-value pairs
    _IterAttrPairs = Generator[_AttrPair, None, None]

    # Filters to choose which attributes to copy or iterate over
    IS_METHOD = Filter(values_are=callable)
    IS_PRIVATE = Filter(names_are=is_private)
    IS_PUBLIC = ~IS_PRIVATE
    IS_PUBLIC_METHOD = IS_PUBLIC + IS_METHOD

    # Public instance variables
    names: set[str]  # All attribute names
    what: Any  # Object to access attributes of

    def __init__(self, what: Any) -> None:
        """
        :param what: Any, the object to select/iterate/copy attributes of. \
            "Attributes of what?" <==> `attributes.AttrsOf(what)`
        """
        self.names = get_names(what)
        self.what = what

    def __contains__(self, name: str) -> bool:
        return hasattr(self.what, name)

    def __delitem__(self, name: str) -> None:
        delattr(self.what, name)

    def __getitem__(self, name: str) -> Any:
        return getattr(self.what, name)

    def __iter__(self) -> Iterator[str]:
        return iter(self.names)

    def __len__(self) -> int:
        return len(self.names)

    def __repr__(self) -> str:
        return f"{name_of(self)}({self.what})"

    def __setitem__(self, name: str, value: Any) -> None:
        setattr(self.what, name, value)

    def add_to(self, an_obj: _T, filter_if: Filter.FilterFunction,
               exclude: bool = False) -> _T:
        """ Copy attributes and their values into `an_obj`.

        :param an_obj: Any, object to add/copy attributes into.
        :param filter_if: Callable[[str, Any], bool] that returns True if \
            the `str` argument passes all of the name filters and \
            the `Any` argument passes all of the value filters, else False
        :param exclude: bool, False to INclude all attributes for which all \
            of the filter functions return True; else False to EXclude them.
        :return: Any, an_obj with the specified attributes of this object.
        """
        pair_generator = self.items() if filter_if is None \
            else self.select(filter_if, exclude)
        for attr_name, attr_value in pair_generator:
            setattr(an_obj, attr_name, attr_value)
        return an_obj

    def but_not(self, *others: Any) -> set[str]:
        """
        :param others: Iterable of objects to exclude attributes shared by
        :return: set[str] naming all attributes that are in this object but \
            not in any of the `others`
        """
        return self.names - get_names(*others)

    def first_of(self, attr_names: Iterable[str], default: Any = None,
                 method_names: Container[str] = set()) -> Any:
        """
        :param attr_names: Iterable[str], attributes to check this object for.
        :param default: Any, what to return if this object does not have any of \
            the attributes named in `attr_names`.
        :param method_names: Container[str], the methods named in \
            `attr_names` to call before returning them.
        :return: Any, `default` if this object has no attribute named in \
            `attr_names`; else the found attribute, executed with no \
            parameters (if in `method_names`)
        """
        found_attr = default
        attrs = self.names.intersection(set(attr_names))
        match len(attrs):
            case 0:
                pass  # found_attr = default
            case 1:
                found_attr = getattr(self.what, attrs.pop())
            case _:
                for name in attr_names:
                    if name in self.names:
                        found_attr = getattr(self.what, name)
                        break
        if name in method_names and callable(found_attr):
            found_attr = found_attr()
        return found_attr

    def items(self) -> _IterAttrPairs:
        """ Iterate over all of this object's attributes.

        :yield: Generator[tuple[str, Any], None, None] that returns the name \
            and value of each selected attribute.
        """
        for name in self.names:
            yield name, getattr(self.what, name)

    def list_names(self, filter_if: Filter.FilterFunction | None = None,
                   exclude: bool = False) -> list[str]:
        """
        :param filter_if: Callable[[str, Any], bool] that returns True if \
            the `str` argument passes all of the name filters and \
            the `Any` argument passes all of the value filters, else False; \
            or None to return a list of all attribute names; defaults to None.
        :param exclude: bool, False to INclude all attributes for which all \
            of the filter functions return True; else False to EXclude them.
        :return: list[str], names of selected attributes of this object.
        """
        return [name for name, _ in self.select(filter_if, exclude)
                ] if filter_if else list(self.names)

    def list_pairs(self, filter_if: Filter.FilterFunction | None = None,
                   exclude: bool = False) -> list[_AttrPair]:
        pair_generator = self.items() if filter_if is None \
            else self.select(filter_if, exclude)
        return [(name, attr) for name, attr in pair_generator]

    # TODO: @cached_property[Callable] #?
    def methods(self) -> Generator[tuple[str, Callable], None, None]:
        """ Iterate over this object's methods (callable attributes).

        :yield: Generator[tuple[str, Any], None, None] that returns the name \
            and value of each method of this object.
        """
        yield from self.select(filter_if=self.IS_METHOD)

    def nested(self, *attribute_names: str) -> Any:
        """ `Of(an_obj).nested("first", "second", "third")` will \
        return `an_obj.first.second.third` if it exists or None otherwise.

        :param attribute_names: Iterable[str] of attribute names. The first \
                                names an attribute of an_obj; the second \
                                names an attribute of the first; etc.
        :return: Any, the attribute of an attribute ... of an attribute of an_obj
        """
        attributes = list(attribute_names)  # TODO reversed(attribute_names) ?
        to_return = self.what
        while attributes and to_return is not None:
            to_return = getattr(to_return, attributes.pop(0), None)
        return to_return

    # TODO: @cached_property[_IterAttrPairs]  # or [list[tuple[str, Any]]]?
    def private(self) -> _IterAttrPairs:
        """ Iterate over this object's private attributes.

        :yield: Generator[tuple[str, Any], None, None] that returns the name \
            and value of each private attribute.
        """
        yield from self.select(filter_if=self.IS_PRIVATE)

    # TODO: @cached_property[_IterAttrPairs]  # or [list[tuple[str, Any]]]?
    def public(self) -> _IterAttrPairs:
        """ Iterate over this object's public attributes.

        :yield: Generator[tuple[str, Any], None, None] that returns the name \
            and value of each public attribute.
        """
        yield from self.select(filter_if=self.IS_PUBLIC)

    def select(self, filter_if: Filter.FilterFunction,
               exclude: bool = False) -> _IterAttrPairs:
        """ Iterate over some of this object's attributes.

        :param filter_if: Callable[[str, Any], bool] that returns True if \
            the `str` argument passes all of the name filters and \
            the `Any` argument passes all of the value filters, else False
        :param exclude: bool, False to INclude all attributes for which all \
            of the filter functions return True; else False to EXclude them.
        :yield: Generator[tuple[str, Any], None, None] that returns the name \
            and value of each selected attribute.
        """
        for name, attr in self.items():
            if filter_if(name, attr) is not exclude:
                yield name, attr

    # TODO: @cached_property[_IterAttrPairs]  # or [list[tuple[str, Any]]]?
    def slots(self) -> Generator[str, None, None]:
        """
        :yield: Generator[str, None, None], the name of each slot \
            (non-read-only attribute) of this object.
        """
        for name in self.names:
            if not is_read_only(self.what, name):
                yield name

    def to_dict(self) -> dict[str, Any]:
        """ 
        :return: dict[str, Any] mapping every attribute's name to its value
        """
        return {name: getattr(self.what, name) for name in self.names}

    # TODO: @cached_property[_IterAttrPairs]  # or [list[tuple[str, Any]]]?
    def variables(self) -> _IterAttrPairs:
        """ Iterate over this object's variables (non-read-only attributes).

        :yield: Generator[tuple[str, Any], None, None] that returns the name \
            and value of each variable attribute.
        """
        for name in self.slots():
            yield name, getattr(self.what, name)

    # _yield_first_item = filter_sequence_generator(0)
    # keys = _yield_first_item(items)
    # method_names = _yield_first_item(methods)   # ?
    # private_names = _yield_first_item(private)  # ?
    # public_names = _yield_first_item(public)    # ?
    # slots = _yield_first_item(variables)        # ?


def slotsof(obj: Any) -> tuple[str, ...]:
    """ Get an object's `__slots__` or its `__dict__` keys.

    Defined to access object attributes without caring which meta-attribute \
    it defines (`__slots__` or `__dict__`). If an object defines neither, \
    then return a tuple of its non-read-only attribute names.

    WARNING: Does not guarantee that slots are in the correct order.

    :param an_obj: Any
    :return: tuple[str, ...], the `__slots__` attribute of `an_obj` if one \
        exists; else the keys of `an_obj.__dict__`
    """
    try:
        return obj.__slots__
    except AttributeError:
        try:
            attr_names = vars(obj)
        except TypeError:
            attr_names = AttrsOf(obj).slots()

        return tuple[str, ...](attr_names)


def varsof(obj: Any) -> dict[str, Any]:
    """ Get an object's `vars`, or its `__slots__` and their values.

    Defined to access object attributes without caring which meta-attribute \
    it defines (`__slots__` or `__dict__`). If an object defines neither, \
    then return a dict of its non-read-only attribute names and values.

    :param an_obj: Any
    :return: dict[str, Any], `vars(an_obj)` if that works; else the names \
        and values of everything in `an_obj.__slots__`
    """
    try:
        return vars(obj)
    except TypeError:
        try:
            slots = obj.__slots__
        except AttributeError:
            slots = AttrsOf(obj).slots()
        return {x: getattr(obj, x) for x in slots}
