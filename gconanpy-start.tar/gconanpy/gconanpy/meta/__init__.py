#!/usr/bin/env python3

"""
Functions/classes to manipulate, define, and/or be manipulated by others.
Greg Conan: gregmconan@gmail.com
Created: 2025-03-26
Updated: 2026-03-02
"""
# Import standard libraries
import abc
import builtins
from collections.abc import Callable, Collection, Hashable, Iterable, Iterator
import functools
from math import log10
# import operator
# from operator import attrgetter, methodcaller  # TODO?
# import pdb
# from types import MappingProxyType  # TODO freeze TimeSpec?
from typing import Any, cast, get_args, Literal, no_type_check, \
    overload, ParamSpec, Self, SupportsFloat, TypeVar

try:
    from gconanpy.meta.typeshed import DATA_ERRORS, Unhashable, \
        SkipException, SupportsItemAccess
except (ImportError, ModuleNotFoundError):  # TODO DRY?
    from .typeshed import DATA_ERRORS, Unhashable, \
        SkipException, SupportsItemAccess

# TypeVars for class methods' input parameters
_D = TypeVar("_D")
_KT = TypeVar("_KT", bound=Hashable)
_VT = TypeVar("_VT")

CALL_2ARG = Callable[[Any, Any], Any]
CALL_3ARG = Callable[[Any, Any, Any], Any]

# MethodWrappingMeta type variables
_P = ParamSpec("_P")
_Super = TypeVar("_Super")
_Sub = TypeVar("_Sub")
_T = TypeVar("_T")


def areinstances(objects: Iterable, of_what: type | tuple[type, ...]) -> bool:
    for each_obj in objects:
        if not isinstance(each_obj, of_what):
            return False
    return True


def bool_pair_to_cases(cond1, cond2) -> int:  # TODO cond*: Boolable
    return sum({x + 1 for x in which_of(cond1, cond2)})


# TODO Move to a file called "wrap", "metafunc", or "wrapfunc"?
def error_changer(old: type[BaseException], new: type[BaseException]
                  ) -> Callable[[Callable[_P, _T]], Callable[_P, _T]]:
    """ Create a wrapper to change which exception a `Callable` raises.

    :param old: type[BaseException] to replace with `new`
    :param new: type[BaseException] to replace `old` with
    :return: Callable[[Callable[_P, _T]], Callable[_P, _T]], \
        function that returns a copy of the input `Callable` identical in \
        every way except that instead of ever raising `old`, it raises `new`.
    """
    def outer(func: Callable[_P, _T]) -> Callable[_P, _T]:
        """ 
        :param func: Callable[_P, _T], any function that can raise {old}
        :raises {new}: if `func` is called and raises {old}
        :return: Callable[_P, _T], a copy of `func` that will raise {new} \
            instead of ever raising {old}
        """
        @functools.wraps(func)
        def inner(*args: _P.args, **kwargs: _P.kwargs) -> _T:
            try:
                return func(*args, **kwargs)
            except old as err:
                raise new(*err.args)
        return inner

    # Return wrapped function with docstring specifying the errors it replaces
    outer.__doc__ = cast(str, outer.__doc__).format(
        old=old.__name__, new=new.__name__)
    return outer


def count_digits_of(a_num: int | float):
    """
    :param a_num: int | float, numeric value to count the digits of
    :return: int, the number of digits in a_num
    """
    absnum = abs(a_num)
    return int(log10(absnum)) + 1 if a_num % 1 == 0 else len(str(absnum)) - 1


# TODO Move to a file called "wrap", "metafunc", or "wrapfunc"?
def divmod_base(n: int) -> Callable[[int], tuple[int, int]]:
    """ Get a function that converts integers into base `n` via `divmod`, \
        but represents a nonzero int with a full remainder.

    `divmod_base(26)` returns a function useful to convert MS Excel \
    column numbers into their letter equivalent.

    Adapted from https://stackoverflow.com/a/48984697

    :param n: int, base (numerical radix).
    :return: Callable[[int], tuple[int, int]], a function that accepts an \
        integer and converts it into base `n`, returning a \
        `(quotient, remainder)` tuple.
    """
    def inner(dividend: int) -> tuple[int, int]:
        """ Convert int `dividend` into base-{n} via `divmod`, \
            but represent a nonzero int with a full remainder.

        :param dividend: int, number to convert into base-{n}
        :return: tuple[int, int], quotient and remainder after \
            converting `dividend` into base-{n}
        """
        quotient, remainder = divmod(dividend, n)
        return (quotient - 1, remainder + n) if remainder == 0 \
            else (quotient, remainder)
    inner.__doc__ = cast(str, inner.__doc__).format(n=n)
    return inner


def full_name_of(an_obj: Any) -> str:
    return ".".join((getattr(an_obj, "__module__"),
                     getattr(an_obj, "__name__")))


def geteverything(**local_vars: Any) -> dict[str, Any]:
    """ Call `geteverything(**locals())` to get every defined name/variable.

    :param local_vars: Mapping[str, Any], local variables to add to the \
        returned `dict`
    :return: dict[str, Any], every global and built-in variable plus all of \
        the local variables given in `local_vars`
    """
    return {**globals(), **vars(builtins), **local_vars}


def has_method(an_obj: Any, method_name: str) -> bool:
    """
    :param an_obj: Any
    :param method_name: str, name of a method that `an_obj` might have.
    :return: bool, True if `method_name` names a callable attribute \
        (method) of `an_obj`; otherwise False.
    """
    return callable(getattr(an_obj, method_name, None))


@overload
def hashable(obj: Hashable) -> Literal[True]: ...
@overload
def hashable(obj: Unhashable) -> Literal[False]: ...
@overload
def hashable(obj: Any) -> bool: ...


def hashable(obj):
    """ 
    :param obj: Any
    :return: bool, True if `obj` is `Hashable`; else False
    """
    try:
        hash(obj)
        return True
    except TypeError:
        return False


def method(method_name: str) -> Callable:
    """ Wrapper to retrieve a specific callable object attribute.
    `method(method_name)(something, *args, **kwargs)` is the same as \
    `getattr(something, method_name)(*args, **kwargs)`.

    :param method_name: str naming the object method for the returned \
        wrapped function to call
    :return: Callable that runs the named method of its first input argument \
        and passes the rest of its input arguments to the method
    """

    def call_method(self: Any, *args: Any, **kwargs: Any):
        """
        :param self: Any, object with a method to call
        :param args: Iterable, positional arguments to call the method with
        :param kwargs: Mapping[str, Any], keyword arguments to call the \
            method with
        :return: Any, the output of calling the method of `self` with the \
            specified `args` and `kwargs`
        """
        return getattr(self, method_name)(*args, **kwargs)

    return call_method


@overload
def name_of(an_obj: Any) -> str: ...
@overload
def name_of(an_obj: Any, get: Literal["__name__", "__qualname__"]) -> str: ...
@overload
def name_of(an_obj: Any, get: Literal["__mro__"]) -> tuple[type, ...]: ...


def name_of(an_obj: Any, get: str = "__name__"):
    """ Get the name of an object or of its type/class.

    :param an_obj: Any, object to get the name of.
    :param attr_name: str naming the attribute of `an_obj` (or of its class) \
        to return. Defaults to "__name__".
    :return: str naming an_obj, usually its type/class name.
    """
    return getattr(an_obj, get, getattr(type(an_obj), get))


def names_of(objects: Collection, max_n: int | None = None,
             get_name: Callable[[Any], str] = name_of) -> list[str]:
    """
    :param objects: Iterable of things to return the names of
    :param max_n: int | None, maximum number of names to return; by default, \
        this function will return all names
    :return: list[str], names of `max_n` (or all) `objects`
    """
    return [get_name(x) for x in objects] if max_n is None else \
        [get_name(x) for i, x in enumerate(objects) if i < max_n]


def tuplify(an_obj: Any, split_string: bool = False) -> tuple:
    """
    :param an_obj: Any, object to convert into a tuple.
    :param split_string: bool, True to split a string into a tuple of \
        its characters; else (by default) False to leave strings intact.
    :return: tuple, either `an_obj` AS a tuple if `tuple(an_obj)` works (and \
        `split_string=True` or `an_obj` isn't a string); else `an_obj` IN a \
        single-item tuple.
    """
    try:
        assert split_string or not isinstance(an_obj, str)
        return tuple(an_obj)
    except (AssertionError, TypeError):
        return (an_obj, )


def which_of(*conditions: Any) -> set[int]:  # TODO conditions: Boolable
    """
    :param conditions: Iterable[Boolable] of items to filter
    :return: set[int], the indices of every truthy item in `conditions`
    """
    return set[int]((i for i, cond in enumerate(conditions) if cond))


class cached_property[T]:
    """ Parameterized version of `textblob.decorators.cached_property`, a 
    property that is only computed once per instance and then replaces itself
    with an ordinary attribute. Deleting the attribute resets the property.

    Credit to Marcel Hellkamp, author of `bottle.py`.
    """

    def __init__(self, func: Callable[..., T]) -> None:
        self.__doc__ = func.__doc__
        self.func = func

    @overload
    def __get__(self, obj: None, cls) -> Self: ...
    @overload
    def __get__(self, obj: Any, cls) -> T: ...

    def __get__(self, obj, cls):
        if obj is None:
            return self
        value = obj.__dict__[self.func.__name__] = self.func(obj)
        return value


class TimeSpec(dict[str, int]):

    # Names of valid TimeSpec options, each corresponding to a duration unit
    UNIT = Literal["auto", "nanoseconds", "microseconds", "milliseconds",
                   "seconds", "minutes", "hours"]
    UNITS = get_args(UNIT)[1:]  # List all time units; exclude "auto"

    # The number of each UNIT per the next unit:
    #   1ns, 1000ns/us, 1000us/ms, 1000ms/sec, 60sec/min, 60min/hr
    OFFSETS = (1, 1000, 1000, 1000, 60, 60)

    def __init__(self) -> None:
        super().__init__()
        units = self.UNITS
        self[units[0]] = self.OFFSETS[0]  # Initialize for iteration
        for i in range(1, len(self.OFFSETS)):  # Calculate unit ratios/offsets
            self[units[i]] = self[units[i-1]] * self.OFFSETS[i]


# `TimeSpec`s need not differ or change. Export this "frozen" dict instead?
# TIME_SPEC = MappingProxyType(TimeSpec())


class BoolableMeta(type):  # https://realpython.com/python-interface/
    """ A metaclass that will be used for Boolable class creation. """
    def __instancecheck__(cls, instance: Any) -> bool:
        try:
            bool(instance)
            return True
        except (TypeError, ValueError):
            return False

    def __subclasscheck__(cls, subclass: type) -> bool:
        return has_method(subclass, "__bool__") \
            or has_method(subclass, "__len__")


class Boolable(metaclass=BoolableMeta):
    """ Any object that you can call `bool()` on is a `Boolable`. """


class Traversible:
    """ Base class for recursive iterators that can visit all items in a \
        nested container data structure. """

    def __init__(self) -> None:
        self.traversed: set[int] = set()

    def _will_now_traverse(self, an_obj: Any) -> bool:
        """
        :param an_obj: Any, object to recursively visit while traversing
        :return: bool, False if `an_obj` was already visited, else True
        """
        objID = id(an_obj)
        not_traversed = objID not in self.traversed
        self.traversed.add(objID)
        return not_traversed


class Recursively:
    _KT = Hashable | tuple[Hashable, ...]

    @staticmethod
    def getitem(an_obj: SupportsItemAccess, key: _KT) -> Any:
        # return functools.reduce(operator.getitem, tuplify(key), an_obj)
        for k in tuplify(key):
            an_obj = an_obj[k]
        return an_obj

    @classmethod
    def getattribute(cls, an_obj: Any, *attr_names: str) -> Any:
        if attr_names:
            return getattr(an_obj, attr_names[0],
                           cls.getattribute(an_obj, *attr_names[1:]))

    @classmethod
    def setitem(cls, an_obj: SupportsItemAccess, key: _KT, value: Any) -> None:
        keys = tuplify(key)
        if len(keys) == 1:
            an_obj[keys[0]] = value
        else:
            cls.setitem(an_obj[keys[0]], keys[1:], value)


class ErrCatcher:
    DEFAULT_CATCH = DATA_ERRORS

    def __init__(self, *catch: type[BaseException]) -> None:
        """
        :param catch: Iterable[type[BaseException]], errors and exceptions \
            to catch and suppress/skip/ignore or handle. If no errors or \
            exceptions are specifically provided, then by default, only the \
            errors and exceptions in the `DEFAULT_CATCH` class variable will \
            be caught.
        """
        self.catch = catch if catch else self.DEFAULT_CATCH


class IgnoreExceptions(ErrCatcher):
    def __enter__(self) -> Self:
        return self

    def __exit__(self, exc_type: type[BaseException] | None = None,
                 *_: Any) -> bool:
        """ Exit the runtime context related to this object. The parameters \
            describe the exception that caused the context to be exited. If \
            the context was exited without an exception, all three arguments \
            will be None.

        Note that __exit__() methods should not reraise the passed-in \
        exception; this is the caller's responsibility.

        Docstring shamelessly stolen from \
        https://docs.python.org/3/reference/datamodel.html#object.__exit__

        :param exc_type: type[BaseException] | None, the `type` of exception \
            caught (or None if no exception occurred)
        :return: bool, True if no exception occurred or if an exception was \
            caught and suppressed; else False to raise the exception
        """
        return (not self.catch) or (exc_type in self.catch)


class SkipOrNot(IgnoreExceptions, abc.ABC):
    def __init__(self, parent: "KeepTryingUntilNoErrors", *catch) -> None:
        super(SkipOrNot, self).__init__(*catch)
        self.parent = parent


class Skip(SkipOrNot):
    def __enter__(self):
        raise SkipException


class DontSkip(SkipOrNot):
    def __exit__(self, exc_type: type[BaseException] | None = None,
                 exc_val: BaseException | None = None, _: Any = None) -> bool:
        """ Upon exiting a code block, inform the parent \
            `KeepSkippingExceptions` context manager whether the code block \
            completed successfully or raised an exception.

        :param exc_type: type[BaseException] | None,_description_, defaults to None
        :param exc_val: BaseException | None,_description_, defaults to None
        :param _: Any,_description_, defaults to None
        :return: bool, _description_
        """
        if exc_val is None:
            self.parent.is_done = True
        else:
            self.parent.errors.append(exc_val)
        return super(DontSkip, self).__exit__(exc_type)


class KeepSkippingExceptions(ErrCatcher):
    def __init__(self, catch: Iterable[type[BaseException]] = [],
                 is_done: bool = False) -> None:
        """
        :param catch: Iterable[type[BaseException]] to catch and skip; \
            defaults to `ErrCatcher.DEFAULT_CATCH` (`DATA_ERRORS`).
        :param is_done: bool, True to skip any remaining code blocks; \
            else False to execute them 
        """
        super(KeepSkippingExceptions, self).__init__(*catch)
        self.errors: list[BaseException] = []
        self.is_done = is_done


class KeepTryingUntilNoErrors(KeepSkippingExceptions):
    def __init__(self, *catch: type[BaseException]) -> None:
        """
        :param catch: Iterable[type[BaseException]] to catch and skip. 
        """
        super(KeepTryingUntilNoErrors, self).__init__(catch)

    def __call__(self) -> SkipOrNot:
        """ Execute the following code block unless a previous code block \
            executed successfully (without raising an exception).

        :return: SkipOrNot, Skip to ignore the following code block; else \
            DontSkip to execute it.
        """
        skip_or_not = Skip if self.is_done else DontSkip
        return skip_or_not(self, *self.catch)

    def __enter__(self) -> Self:
        """ Must be explicitly defined here (not only in a superclass) for \
            VSCode to realize that KeepTryingUntilNoErrors(...) returns an \
            instance of the KeepTryingUntilNoErrors class.

        :return: KeepTryingUntilNoErrors, self.
        """
        return self

    def __exit__(self, exc_type: type[BaseException] | None = None,
                 *_: Any) -> bool:
        return exc_type is SkipException


class IteratorFactory:
    _T = TypeVar("_T")

    @classmethod
    def first_element_of(cls, an_obj: Iterable[_T] | _T) -> _T:
        """ Get `an_obj`'s first element if `an_obj` is iterable; \
            else simply return `an_obj` unchanged.

        :param an_obj: Iterable to return the first element of, or Any.
        :return: Any, the first element of `an_obj` if `an_obj` is iterable; \
                 else `an_obj`
        """
        return next(cls.iterate(an_obj))

    @no_type_check
    @classmethod
    def iterate(cls, an_obj: Iterable[_T] | _T) -> Iterator[_T]:
        """ Iterate `an_obj`.

        :param an_obj: Iterable to iterate over, or Any.
        :return: Iterator over `an_obj` or its elements/values.
        """
        with KeepTryingUntilNoErrors(*DATA_ERRORS) as next_try:
            with next_try():
                iterator = iter(an_obj.values())
            with next_try():
                iterator = iter(an_obj)
            with next_try():
                iterator = iter([an_obj])
        return iterator


class Comparer(IteratorFactory):
    # Class type variables for type hints
    Comparable = TypeVar("Comparable")  # Comparison function input arg(s)
    Comparee = TypeVar("Comparee")      # Item being compared to other items
    Comparison = Callable[[Comparable, Comparable], bool]  # Comparer function
    ToNumber = Callable[[Comparable], SupportsFloat]  # Sizer function
    ToComparable = Callable[[Comparee], Comparable]   # Sizer metafunction

    @classmethod
    def comparison(cls, smallest: bool = False, earliest: bool = False
                   ) -> Comparison:
        """ Get function that compares two `SupportsFloat` objects.

        smallest & earliest => `x.__lt__(y)` (Less Than),
        biggest & latest => `x.__ge__(y)` (Greater than or Equal to), etc.

        :param smallest: bool,_description_, defaults to False
        :param earliest: bool,_description_, defaults to False
        :return: Comparison, function that takes 2 `SupportsFloat` objects, \
            calls an inequality method of the first's on the second, and \
            returns the (boolean) result.
        """
        return method(f'__{"l" if smallest else "g"}'
                      f'{"t" if earliest else "e"}__')

    @classmethod
    def size_of(cls, item: Any, get_size: ToNumber,
                make_comparable: ToComparable) -> SupportsFloat:
        """ Get an item's size as a float.

        :param item: Any, item to return the size of
        :param get_size: Callable[[Any], SupportsFloat], comparison \
            function that converts an item into a numerical value to return
        :param make_comparable: Callable[[Any], Any], secondary comparison \
            function that converts an item into an input acceptable by \
            `compare_their` to convert to a numerical value to return
        :return: SupportsFloat, size of `item`
        """
        try:
            item_size = get_size(item)
        except DATA_ERRORS:
            try:
                item_size = get_size(make_comparable(item))
            except DATA_ERRORS:
                item_size = 1.0
        return item_size

    @classmethod
    def compare(cls, items: Iterable[Comparee], compare_their: ToNumber = len,
                make_comparable: ToComparable = str,
                smallest: bool = False, earliest: bool = False) -> Comparee:
        """ Get the biggest (or smallest) item in `items`. 

        :param items: Iterable[Any], things to compare.
        :param compare_their: Callable[[Any], SupportsFloat], comparison \
            function, defaults to `len`
        :param make_comparable: Callable[[Any], Any], comparison \
            function, defaults to `str`
        :param default: Any, starting item to compare other items against
        :return: Any, item with the largest value returned by calling \
            `compare_their(make_comparable(`item`))`.
        """
        if not items:
            raise ValueError("No items for Comparer.compare to compare!")
        compare = cls.comparison(smallest, earliest)
        biggest = cls.first_element_of(items)
        max_size = cls.size_of(biggest, compare_their, make_comparable)
        for item in items:
            item_size = cls.size_of(item, compare_their, make_comparable)
            if compare(item_size, max_size):  # item_size >= max_size:
                biggest = item
                max_size = item_size
        return biggest


class MethodWrappingMeta(type):
    """ Metaclass to wrap all instance methods of a class.

    Ensures that any method of the wrapper subclass which ordinarily \
    returns an instance of the wrapped superclass will instead return \
    an instance of the wrapper subclass.

    Adapted from pythontutorials.net/blog/how-to-wrap-every-method-of-a-class
    """
    # Defined here instead of metaclass.py bc it has no gconanpy dependencies

    ASSIGNED = ("__doc__", "__name__", "__text_signature__")

    def __new__(cls, name: str, bases: tuple[type[_Super], ...],
                namespace: dict[str, Any], /, **kwds: Any):
        old_class = bases[0]

        # Create the new class
        new_class = super().__new__(cls, name, bases, namespace)

        # Wrap every method of the class; check all attributes to find methods
        for attr_name in dir(old_class):
            old_attr = getattr(old_class, attr_name)
            new_method = getattr(new_class, attr_name)
            # Skip non-methods and special methods
            if (not attr_name.startswith("__")) and callable(old_attr) \
                    and callable(new_method):
                # Wrap the method
                setattr(new_class, attr_name, cls.wrap_method_of(
                    new_class, old_class, name, new_method))
        return new_class

    @classmethod
    def wrap_method_of(cls, new_class: type[_Sub], old_class: type[_Super],
                       new_cls_name: str, new_meth: Callable[_P, _T | _Super]
                       ) -> Callable[_P, _T | _Sub]:
        @functools.wraps(new_meth, assigned=cls.ASSIGNED)
        def wrapper(*args: _P.args, **kwargs: _P.kwargs) -> _T | _Sub:
            ret = new_meth(*args, **kwargs)
            return cast(_T, ret) if not isinstance(ret, old_class) else \
                cast(_Sub, new_class(ret))  # pyright: ignore[reportCallIssue]

        setattr(wrapper, "__objclass__", new_class)
        setattr(wrapper, "__self__", new_class)
        wrapper.__qualname__ = f"{new_cls_name}.{wrapper.__name__}"
        return wrapper
